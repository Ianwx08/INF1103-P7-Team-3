# TinyScreen+ enclosure: dimensioned concept v6

All dimensions in millimetres. This is a proposed layout, not printable geometry or a verified assembly.

## Confirmed inputs

| Item | Size |
|---|---|
| Screen opening | 25 wide x 16.5 high |
| Concealed upper strip | 8 high; previous measured width 25.5 |
| Full five-board assembly | 26 wide x 25 high x 21 deep |
| Reserved stack depth | 22, including 1 extra over measured stack |
| Native switch bodies | 1.9 along edge, 5 gap between bodies, 6.9 center pitch |
| Screen-to-button separation | 0.3, not assumed switch travel |
| Camera housing | 9 x 5 |
| Camera PCB | 18 x 10, oriented landscape in this proposal |
| Buzzer body | 8.5 x 8.5 |
| Buzzer PCB | 17 x 11 |
| Battery | 19 x 23 x 5 |
| Wireling cables | Approximately 50 each |
| Extra clearance around connected wires/plugs | 0.4, separate from their physical envelope |

## Proposed enclosure and placement

- Case target: 64 wide x 82 high x 40 deep, nominal 2 mm walls, removable back. Depth retained provisionally until connectors and routing are established.
- Screen opening origin: 19.5 from left, 24 from top. Its bottom is at 40.5.
- Upper strip is covered by bezel, not exposed through an additional opening. It is already included in the full 25 mm board height; do not add it to that height again. Recess depth remains to determine.
- Full PCB nominal projection: x=19..45, y=15.5..40.5, based on proposed alignment. Supports cannot press on the glass or components.
- Four independent guided side plungers, two each side. Provisional switch centers y=28.05 and 34.95, inferred from a 4.6 mm lower-edge gap, 1.9 mm bodies and 5 mm inter-body gap. These are not independently verified absolute positions or switch depth measurements.
- Camera PCB center (25, 48.5), provisional pocket 18.4 x 10.4 in-plane. Buzzer PCB center (45, 48.5), provisional pocket 17.4 x 11.4. These pockets apply 0.4 total dimensional fit allowance, 0.2 each side. Extra plug space is additional.
- Camera aperture remains open and chamfered; housing size is not automatically aperture size. Final aperture depends on recess and unobstructed field of view.
- Battery bay x=19.5..44.5, y=55..79, nominal 25 x 24 x 7. Battery oriented 19 wide x 23 high x 5 deep. No clamping load on battery pouch, no screw intrusion.
- Both camera and buzzer mount below the board stack at the front. Their final depths must allow smooth routes from the adapter using the actual 50 mm cables.
- Nominal internal case depth is 36. Reserved stack is 22. The remaining 14 is shared by supports and plug/bend envelopes, not a proven clearance at every connector.

## Unresolved before printable CAD

Switch operating travel, actuation plane and protrusion; absolute center datum; sensor assembly thicknesses; connected plug envelopes and adapter port locations; usable battery lead reach; USB and power-switch access; support/mounting locations; print process fit tolerance. A 0.4 extra allowance does not mean connectors or bends fit inside a 0.4 slot.
