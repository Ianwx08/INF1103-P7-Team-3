// TinyScreen+ hand-held two-switch test, units mm.
// Open in OpenSCAD. Choose part, press F6, then export STL.
// Start with reach=0.2. Reach is NOT a known safe switch stroke.
// Guide face must be aligned with the resting actuator tips, not forced onto PCB.
part = "assembly"; // guide, plunger, assembly
reach = 0.2; // alternatives: 0.5, 0.8
pitch = 6.9;
guide_length = 8;
guide_width = 14;
guide_height = 6;
bore = 3;
shaft = 2.4; // 0.3 clearance each side; tune for printer
head = 5;
head_thickness = 2;
function centers() = [3.55, 3.55+pitch];
module guide(){
 difference(){
  cube([guide_length,guide_width,guide_height]);
  for(y=centers()) translate([-0.1,y-bore/2,(guide_height-bore)/2])
   cube([guide_length+0.2,bore,bore]);
 }
}
module plunger(){
 union(){
  cube([head_thickness,head,head]);
  translate([head_thickness,(head-shaft)/2,(head-shaft)/2])
   cube([guide_length+reach,shaft,shaft]);
 }
}
// Cyclic coordinate transform: bores vertical, plunger head flat for printing.
if(part=="guide") multmatrix([[0,1,0,0],[0,0,1,0],[1,0,0,0],[0,0,0,1]]) guide();
if(part=="plunger") multmatrix([[0,1,0,0],[0,0,1,0],[1,0,0,0],[0,0,0,1]]) plunger();
if(part=="assembly"){
 color("silver") guide();
 for(y=centers()) color("orange")
  translate([-head_thickness,y-head/2,(guide_height-head)/2]) plunger();
}
