// EDITABLE ENCLOSURE DRAFT, NOT A VERIFIED PRINT-READY ASSEMBLY.
// Units mm. Axes: x left-to-right, y top-to-bottom, z front-to-back.
// Switch depth/operating travel, plugs, supports and access positions need validation.
// No internal board supports yet: do NOT install electronics without a fitted cradle.
// Fit-test mechanism is in tinyscreen_button_fit_test.scad.
part = "assembly"; // front_shell, rear_lid, assembly
W=64; H=82; D=40; wall=2; lid_thickness=2;
screen_w=25; screen_h=16.5; screen_x=(W-screen_w)/2; screen_y=24;
upper_strip_h=8; upper_strip_w=25.5;
board_w=26; board_h=25; measured_stack=21; reserved_stack=22;
board_x=(W-board_w)/2; board_y=15.5;
button_pitch=6.9;
// Inferred from lower screen edge. Verify against physical switch centers.
button_centers=[screen_y+screen_h-12.45,screen_y+screen_h-5.55];
button_axis_z=4.5; // PLACEHOLDER: must be measured before full-case fit
button_bore=3;
camera_center=[25,48.5]; camera_PCB=[18,10];
buzzer_center=[45,48.5]; buzzer_PCB=[17,11];
battery=[19,23,5]; battery_bay=[25,24,7];
extra_connector_clearance=0.4; // additional to actual plug envelope, not a cable slot size
camera_aperture=[11,7]; // PROPOSED clearance, optical recess/FOV still to verify
// Camera, buzzer and battery volumes are reference envelopes only.
// Their mounts, physical plugs and 50 mm cable paths are not yet modeled.
module front_shell(){
 difference(){
  cube([W,H,D-lid_thickness]);
  translate([wall,wall,wall]) cube([W-2*wall,H-2*wall,D]);
  translate([screen_x,screen_y,-1]) cube([screen_w,screen_h,wall+2]);
  // Blind internal relief covers upper hardware strip; leaves 1 mm front skin.
  translate([(W-upper_strip_w)/2,screen_y-upper_strip_h,1])
   cube([upper_strip_w,upper_strip_h,wall+1]);
  translate([camera_center[0]-camera_aperture[0]/2,
   camera_center[1]-camera_aperture[1]/2,-1])
   cube([camera_aperture[0],camera_aperture[1],wall+2]);
  for(i=[-1:1]) translate([buzzer_center[0]-4,buzzer_center[1]+i*2-0.5,-1])
   cube([8,1,wall+2]);
  // Only external port bores; long guides and plungers depend on fit-test result.
  for(y=button_centers){
   translate([-1,y-button_bore/2,button_axis_z-button_bore/2])
    cube([wall+2,button_bore,button_bore]);
   translate([W-wall-1,y-button_bore/2,button_axis_z-button_bore/2])
    cube([wall+2,button_bore,button_bore]);
  }
 }
}
module rear_lid(){
 // Loose locating lid with 0.2 clearance per side. Fasteners not yet designed.
 union(){
  cube([W,H,lid_thickness]);
  translate([wall+0.2,wall+0.2,-1]) difference(){
   cube([W-2*wall-0.4,H-2*wall-0.4,1.01]);
   translate([1,1,-0.1]) cube([W-2*wall-2.4,H-2*wall-2.4,1.3]);
  }
 }
}
module reference_volumes(){
 // Transparent dimensional envelopes. Not printable solids in shell/lid modes.
 %translate([board_x,board_y,3]) cube([board_w,board_h,reserved_stack]);
 %translate([camera_center[0]-9,camera_center[1]-5,2]) cube([18,10,8]);
 %translate([buzzer_center[0]-8.5,buzzer_center[1]-5.5,2]) cube([17,11,7]);
 %translate([(W-battery_bay[0])/2,55,2]) cube(battery_bay);
}
if(part=="front_shell") front_shell();
if(part=="rear_lid") translate([0,0,1]) rear_lid();
if(part=="assembly"){
 color("lightgray") front_shell();
 translate([W+12,0,1]) color("gray") rear_lid();
 reference_volumes();
}
