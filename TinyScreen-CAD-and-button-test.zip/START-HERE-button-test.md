# TinyScreen+ button fit test

This kit tests one pair of native side switches at 6.9 mm center pitch. Use the same guide for the other side. It is a hand-held alignment jig, not a clamp or a fitted board holder: the board stack is not locked into an unverified cradle.

## Files

- `button-guide-6p9mm.stl`: print one. Two 3 x 3 mm through bores, 6.9 mm apart, 8 mm long. Print orientation supplied: bores vertical, base 14 x 6, height 8.
- `button-plunger-reach-0.2mm.stl`: print two first. Head 5 x 5 x 2, shaft 2.4 x 2.4, shaft length 8.2. Maximum nose reach past a guide face is 0.2 when head meets guide.
- `button-plunger-reach-0.5mm.stl` and `...0.8mm.stl`: optional longer alternatives. These values are NOT known safe switch travel.
- `tinyscreen_button_fit_test.scad`: editable parametric CAD source, with assembly preview and part selection.
- `tinyscreen_enclosure_draft.scad`: editable enclosure draft. No validated electronics supports, button guides, final plungers, fasteners, USB opening or power-switch opening. Do not print it as a finished functional case.
- `confirmed-design-dimensions-v6.md`: confirmed inputs and outstanding fit measurements.

## Printing

STLs use millimetres. A starting point is PLA, a 0.4 mm nozzle, 0.16-0.20 mm layers, 3 walls, and no supports. Print plunger heads flat on the bed. Avoid a brim attached to sliding shafts. Printer accuracy affects the 0.3 mm-per-side sliding clearance. If a plunger binds, adjust shaft/bore in the source or remove print artifacts; do not force it against the electronics.

## Test sequence

1. Power the board off and unplug USB before placing the guide. Keep metal tools away from circuitry. Support the stack on suitable PCB edges, not the OLED glass or delicate components.
2. Print one guide and two 0.2 mm plungers. Check both slide independently and freely OUTSIDE the board first. Neither should catch, twist into a jam or require force to return.
3. Insert plungers with heads on the outside. Position the two bore centers opposite the two actuator tips. Hold the guide so its inner face is aligned with the resting actuator-tip plane. Do not wedge or press the guide onto components. The guide is movable in height and depth because these dimensions are not verified yet.
4. Slowly push ONE plunger using only normal light button pressure. Stop at the click or immediately if the board shifts, the guide contacts other components, or resistance rises. Never force the head against its stop to obtain a click.
5. Release. Check that the switch releases and the plunger returns freely. Test each switch separately on both sides. If friction prevents return, correct the fit before proceeding.
6. If 0.2 does not reach/click, first verify the guide-to-actuator gap and alignment. Only then try a longer alternative cautiously. A longer nose can preload or damage a switch if the guide is incorrectly positioned.
7. Once mechanically free, hold the guide securely and check input detection with your existing button-test firmware if available. The kit includes no electronics firmware. Pass criterion: each press and release registers independently, no stuck input and no movement of the board stack.

## What to report

- Which reach clicks and releases reliably on all four switches: 0.2, 0.5 or 0.8, or none.
- Whether the two guide bores align with both switches simultaneously.
- The distance from the front screen surface to the bore centerline when aligned. This establishes the pressing depth in the enclosure; the reported 0.3 mm gap is not assumed to be that centerline or switch travel.
- Any obstruction from PCB edges, OLED frame or components.
- Whether plungers return without help.

Passing this test validates a short sliding guide only. The full enclosure needs longer supported extensions to bridge the gap from the case sides to the switches, plus measured stop positions. Full-case cable plug envelopes, sensor assembly thickness, USB/power access and supports are still unverified.

## Draft enclosure dimensions

64 W x 82 H x 40 D; screen opening 25 x 16.5; 8 high concealed strip; full board envelope 26 x 25 x 21 with 22 reserved depth. Four side ports use a placeholder z=4.5 axis, NOT a confirmed fit. Camera opening is proposed 11 x 7 and must be checked against sensor recess and optical clearance. Rear lid only has a locating lip; retention is unfinished. Camera/buzzer reference depth blocks are placeholders, not measured mounts. The 0.4 extra wire clearance is additional to physical connectors and bends.

Open `.scad` files in OpenSCAD. Select `part`, render with F6, then export STL. Fit-test source part exports are preoriented with bores vertical / heads flat. Source units are mm. No STEP or native FreeCAD files are included.
