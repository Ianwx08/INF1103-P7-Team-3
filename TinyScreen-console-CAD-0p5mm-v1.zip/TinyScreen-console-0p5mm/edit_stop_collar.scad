// Units mm. Read README. Isolated printable component.
use <TinyScreen_console.scad>;
stop_collar();
