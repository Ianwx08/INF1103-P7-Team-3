// Units mm. Read README. Isolated printable component.
use <TinyScreen_console.scad>;
front_shell();
