import json,itertools,sys
from pathlib import Path
O=Path(__file__).resolve().parent; specs=json.loads((O/'geometry_definition.json').read_text())
# transform = (source-axis index, sign, offset), for each world coordinate.
I=((0,1,0),(1,1,0),(2,1,0))
items=[('shell','front_shell',I),('lid','rear_lid',((0,1,0),(1,1,0),(2,-1,40))),
 ('cradle','board_cradle',((0,1,16.8),(1,1,13.3),(2,-1,26.4))),
 ('retainer','sensor_retainer',((0,1,12),(1,1,52.5),(2,1,8.4)))]
for n,y in enumerate((28.05,34.95)):
 items += [(f'L{n}','side_button_0p5',((2,1,-2),(0,1,y-2.5),(1,1,2))),
  (f'R{n}','side_button_0p5',((2,-1,66),(0,1,y-2.5),(1,1,2))),
  (f'LC{n}','stop_collar',((2,1,6.7),(0,1,y-2.3),(1,1,2.2))),
  (f'RC{n}','stop_collar',((2,-1,57.3),(0,1,y-2.3),(1,1,2.2)))]
release=float(sys.argv[1]) if len(sys.argv)>1 else 0
items=[(n,k,tuple((axis,sgn,offset+((-release if n.startswith('L') else release) if d==0 and n.startswith(('L','R')) else 0)) for d,(axis,sgn,offset) in enumerate(t))) for n,k,t in items]
def transbox(b,t):
 lo=[];hi=[]
 for k,s,o in t:
  v=[round(b[k]*s+o,6),round(b[k+3]*s+o,6)];lo.append(min(v));hi.append(max(v))
 return lo+hi
def within(p,b):return all(b[k]+1e-8<p[k]<b[k+3]-1e-8 for k in range(3))
def occupied(p,s):
 if s['outline']:
  poly=s['outline']
  for a,b in zip(poly,poly[1:]+poly[:1]):
   if (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]) < -1e-7:return False
 return ((any(within(p,b) for b in s['base']) and not any(within(p,b) for b in s['base_cuts'])) or any(within(p,b) for b in s['add'])) and not any(within(p,b) for b in s['cuts'])
def local(p,t):
 q=[0,0,0]
 for d,(k,s,o) in enumerate(t):q[k]=(p[d]-o)*s
 return q
def details(item):
 name,key,t=item;s=specs[key];bs=[transbox(b,t) for category in ('base','base_cuts','add','cuts') for b in s[category]]
 solids=[transbox(b,t) for b in s['base']+s['add']]
 lo=[min(b[k] for b in solids) for k in range(3)];hi=[max(b[k+3] for b in solids) for k in range(3)]
 return name,s,t,bs,lo+hi
allitems=[details(i) for i in items];results=[]
for a,b in itertools.combinations(allitems,2):
 bounds=[max(a[4][k],b[4][k]) for k in range(3)]+[min(a[4][k+3],b[4][k+3]) for k in range(3)]
 if any(bounds[k+3]-bounds[k]<1e-6 for k in range(3)):continue
 axes=[]
 for k in range(3):
  vs={bounds[k],bounds[k+3]}
  for q in a[3]+b[3]:
   for v in (q[k],q[k+3]):
    if bounds[k]<v<bounds[k+3]:vs.add(v)
  ss=sorted(vs);axes.append([(x+y)/2 for x,y in zip(ss,ss[1:]) if y-x>1e-6])
 collision=None
 for p in itertools.product(*axes):
  if occupied(local(p,a[2]),a[1]) and occupied(local(p,b[2]),b[1]):collision=p;break
 results.append({'parts':[a[0],b[0]],'positive_volume_overlap_sample':collision})
 assert collision is None,(a[0],b[0],collision)
report={'method':'CSG boundary-grid interior sample check of modeled printed parts. Does not validate hardware envelopes or cable paths.', 'button_release_mm':release,
 'tested_pairs_with_overlapping_bounds':len(results),'results':results}
(O/('assembly_clearance_checks_'+str(release)+'.json')).write_text(json.dumps(report,indent=2));print('No positive-volume printed-part interference in '+str(len(results))+' broad-phase overlapping pairs. Button release='+str(release))
