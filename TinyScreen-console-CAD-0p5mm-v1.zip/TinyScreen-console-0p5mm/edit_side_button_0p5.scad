// Units mm. Read README. Isolated printable component.
use <TinyScreen_console.scad>;
side_button_0p5();
