"""Parametric box CSG clipped to a convex outline; exports matching SCAD + STL.
Pure standard library. Fabrication prototype, not a verified hardware fit.
"""
from pathlib import Path
from collections import Counter
import math, struct, json, zipfile
OUT=Path(__file__).resolve().parent

def box(x,y,z,w,h,d): return tuple(round(v,6) for v in (x,y,z,x+w,y+h,z+d))
def rounded_outline(w,h,r):
 p=[]
 for cx,cy,start in ((w-r,h-r,0),(r,h-r,90),(r,r,180),(w-r,r,270)):
  for j in range(9):
   a=math.radians(start+j*90/8);p.append((round(cx+r*math.cos(a),6),round(cy+r*math.sin(a),6)))
 return p

def clipped(poly,clip):
 for a,b in zip(clip,clip[1:]+clip[:1]):
  if not poly:return []
  def side(p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
  result=[]
  for p,q in zip(poly,poly[1:]+poly[:1]):
   sp,sq=side(p),side(q); ip,iq=sp>=-1e-8,sq>=-1e-8
   if ip:result.append(p)
   if ip != iq:
    t=sp/(sp-sq);result.append(tuple(round(p[k]+t*(q[k]-p[k]),6) for k in range(2)))
  poly=[]
  for p in result:
   if not poly or p!=poly[-1]:poly.append(p)
  if len(poly)>1 and poly[0]==poly[-1]:poly.pop()
 return poly

def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def make_mesh(add,sub,outline=None,base_cuts=None,features=None):
 base_cuts=base_cuts or [];features=features or []
 allb=add+sub+base_cuts+features
 axes=[sorted({b[k] for b in allb}|{b[k+3] for b in allb}) for k in range(3)]
 def inside(p,b):return all(b[k]<p[k]<b[k+3] for k in range(3))
 footprints={}
 for i in range(len(axes[0])-1):
  for j in range(len(axes[1])-1):
   x0,x1=axes[0][i:i+2];y0,y1=axes[1][j:j+2]
   p=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
   if outline:p=clipped(p,outline)
   if len(p)>=3 and area(p)>1e-8:footprints[i,j]=p
 occupied=set();vol=0
 for (i,j),poly in footprints.items():
  for k in range(len(axes[2])-1):
   p=tuple((axes[d][n]+axes[d][n+1])/2 for d,n in enumerate((i,j,k)))
   if ((any(inside(p,b) for b in add) and not any(inside(p,b) for b in base_cuts)) or any(inside(p,b) for b in features)) and not any(inside(p,b) for b in sub):
    occupied.add((i,j,k));vol+=area(poly)*(axes[2][k+1]-axes[2][k])
 triangles=[]
 def face(p):
  for n in range(1,len(p)-1):
   a,b,c=p[0],p[n],p[n+1]
   normal=cross(tuple(b[d]-a[d] for d in range(3)),tuple(c[d]-a[d] for d in range(3)))
   if sum(q*q for q in normal)>1e-16:triangles.append((a,b,c))
 for i,j,k in sorted(occupied):
  poly=footprints[i,j];z0,z1=axes[2][k:k+2]
  if (i,j,k-1) not in occupied:face([(x,y,z0) for x,y in reversed(poly)])
  if (i,j,k+1) not in occupied:face([(x,y,z1) for x,y in poly])
  x0,x1=axes[0][i:i+2];y0,y1=axes[1][j:j+2]
  for a,b in zip(poly,poly[1:]+poly[:1]):
   neighbor=None
   if a[0]==b[0]==x0:neighbor=(i-1,j,k)
   elif a[0]==b[0]==x1:neighbor=(i+1,j,k)
   elif a[1]==b[1]==y0:neighbor=(i,j-1,k)
   elif a[1]==b[1]==y1:neighbor=(i,j+1,k)
   if neighbor is not None and neighbor in occupied:continue
   face([(a[0],a[1],z0),(b[0],b[1],z0),(b[0],b[1],z1),(a[0],a[1],z1)])
 return triangles,vol

def write_stl(name,tris,expected):
 # Quantize to the actual binary STL representation BEFORE checking topology.
 tris=[tuple(tuple(struct.unpack('<f',struct.pack('<f',v))[0] for v in p) for p in tri) for tri in tris]
 edges=Counter();directed=Counter();volume=0
 for a,b,c in tris:
  n=cross(tuple(b[d]-a[d] for d in range(3)),tuple(c[d]-a[d] for d in range(3)))
  assert sum(q*q for q in n)>0,'degenerate triangle'
  volume+=sum(a[d]*cross(b,c)[d] for d in range(3))/6
  for u,v in ((a,b),(b,c),(c,a)):edges[tuple(sorted((u,v)))]+=1;directed[u,v]+=1
 bad=[(e,n) for e,n in edges.items() if n!=2]
 assert not bad,(name,'nonmanifold',bad[:3])
 assert all(n==directed[v,u] for (u,v),n in directed.items()),'winding'
 assert abs(volume-expected)<max(0.03,expected*2e-5),(name,volume,expected)
 verts={p for t in tris for p in t}
 # Count connected triangle components using shared vertices.
 parent={v:v for v in verts}
 def root(v):
  while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
  return v
 for a,b,c in tris:
  ra=root(a)
  for p in (b,c):parent[root(p)]=ra
 components=len({root(v) for v in verts});assert components==1,(name,components)
 with (OUT/(name+'.stl')).open('wb') as f:
  f.write(('TinyScreen console 0.5 reach | '+name+' | mm').encode()[:80].ljust(80,b' '));f.write(struct.pack('<I',len(tris)))
  for a,b,c in tris:
   n=cross(tuple(b[d]-a[d] for d in range(3)),tuple(c[d]-a[d] for d in range(3)));s=math.sqrt(sum(q*q for q in n))
   f.write(struct.pack('<12fH',*(q/s for q in n),*a,*b,*c,0))
 return {'part':name,'triangles':len(tris),'closed_manifold':True,'consistent_winding':True,
  'connected_components':components,'volume_mm3':round(volume,3),
  'bounds_mm':[[round(min(p[d] for p in verts),4) for d in range(3)],[round(max(p[d] for p in verts),4) for d in range(3)]]}

# Authoritative parameters, all mm. Unmeasured defaults called out in README.
P={'case':[64,82,40],'wall':2,'corner_radius':6,'screen':[25,16.5],
 'screen_origin':[19.5,24],'upper_strip_height':8,'board':[26,25,21],
 'board_origin':[19,15.5,2.4],'reserved_stack':22,'button_y':[28.05,34.95],
 'button_axis_z':4.5,'button_pitch':6.9,'reach':0.5,'actuator_tip_left_x':18.5,
 'guide_bore':3,'shaft':2.4,'camera_pcb':[18,10],'camera_center':[25,49],
 'camera_aperture_center':[23.5,49],'camera_aperture':[11,7],
 'camera_seat_z':6,'buzzer_pcb':[17,11],'buzzer_center':[45,49],
 'buzzer_seat_z':6,'battery':[19,23,5],'battery_bay':[25,24,7],
 'wireling_length':50,'extra_plug_clearance':0.4,'screw_pilot':1.6,'screw_clearance':2.4}
outline=rounded_outline(64,82,6)
shell_add=[box(0,0,0,64,82,38)]
# Stepped inner corners give robust walls under the rounded exterior.
shell_sub=[box(6,2,2,52,78,38),box(2,6,2,60,70,38),box(3.5,3.5,2,57,75,38)]
# Front screen and blind hardware relief (0.8 front skin, covered upper strip).
shell_sub += [box(19.5,24,-1,25,16.5,4),box(18.8,15.3,0.8,26.4,25.4,1.3),
 box(18,45.5,-1,11,7,4)]
for y in (46.5,48.5,50.5):shell_sub.append(box(41,y,-1,8,1,4))
# Cavity is subtracted first; features are then unioned, with final holes cut last.
features=[];cuts=[]
for y in P['button_y']:
 for x,w in ((1.5,4.5),(14.5,4),(45.5,4),(58,4.5)):
  features.append(box(x,y-2.5,1.9,w,5,5.1))
 for x in (-1,45.4):cuts.append(box(x,y-1.5,3,19.6,3,3))
# Rear screw bosses, M2 self-tapping pilot. Pockets permit partially recessed heads.
for x,y in ((7,7),(57,7),(7,75),(57,75)):
 features.append(box(x-3.5,y-3.5,1.9,7,7,36.1))
 cuts.append(box(x-.8,y-.8,29.5,1.6,1.6,9.5))
# Sensor trays: open toward stack for cable exit, ledges under PCB edges.
for cx,cy,w,h in ((25,49,18,10),(45,49,17,11)):
 x=cx-w/2-.2;y=cy-h/2-.2
 features += [box(x-1.2,y,1.9,1.2,h+.4,6.5),box(x+w+.4,y,1.9,1.2,h+.4,6.5),
  box(x,y,1.9,.8,h+.4,4.1),box(x+w-.4,y,1.9,.8,h+.4,4.1),
  box(x-1.2,y+h+.4,1.9,w+2.8,1.2,6.5)]
# Separate retainer across sensor backs, screws outside PCBs.
for x in (13.5,56):
 features.append(box(x-1.5,52.5,1.9,3,3,6.5));cuts.append(box(x-.8,53.2,4,1.6,1.6,5))
# Battery bay with strap slots; open top for leads.
features += [box(18.3,55.8,1.9,1.2,24,7.1),box(44.5,55.8,1.9,1.2,24,7.1),box(18.3,79.8,1.9,27.4,1.2,7.1)]
for x in (18,44.2):cuts.append(box(x,65,4,1.8,4,2))

# Store two-stage CSG so hollowing the shell does not erase guide/tray features.
parts={}
parts['front_shell']={'base':shell_add,'base_cuts':shell_sub,'add':features,'cuts':cuts,'outline':outline}
# Rear lid, outside face at local z=0. Assembly maps z -> 40-z.
lidadd=[box(0,0,0,64,82,2)]
# Locating lip, only inner flat stretches to avoid screw bosses.
lidadd += [box(12,2.2,2,40,1,1),box(12,78.8,2,40,1,1),box(2.2,12,2,1,58,1),box(60.8,12,2,1,58,1)]
# Spacer posts hold removable rear cradle at assembly z=24.4..26.4.
for x,y in ((18.3,14.8),(45.7,14.8),(18.3,41.2),(45.7,41.2)):
 lidadd.append(box(x-1.5,y-1.5,1.9,3,3,11.7))
lidcuts=[]
for x,y in ((7,7),(57,7),(7,75),(57,75)):
 lidcuts += [box(x-1.2,y-1.2,-1,2.4,2.4,5),box(x-2.2,y-2.2,-.1,4.4,4.4,.9)]
parts['rear_lid']={'base':lidadd,'base_cuts':[],'add':[],'cuts':lidcuts,'outline':outline}
# Cradle printed rear face down, mapped z -> 26.4-z for assembly.
parts['board_cradle']={'base':[box(0,0,0,30.4,29.4,2)],
 'base_cuts':[box(2.7,2.7,-1,25,24,4)],
 'add':[box(.8,.8,1.9,1.2,27.8,3.1),box(28.4,.8,1.9,1.2,27.8,3.1),
 box(.8,.8,1.9,28.8,1.2,3.1),box(.8,27.4,1.9,28.8,1.2,3.1)],'cuts':[],'outline':None}
# Long plunger is printed cap down. Assembled left shaft goes x=0..19.
parts['side_button_0p5']={'base':[box(0,0,0,5,5,2),box(1.3,1.3,1.9,2.4,2.4,19.1)],
 'base_cuts':[],'add':[],'cuts':[],'outline':None}
# Optional collar: slips over shaft, M2 x3 locking screw from side. Print bore vertical.
parts['stop_collar']={'base':[box(0,0,0,4.6,4.6,3)],'base_cuts':[], 'add':[],
 'cuts':[box(1,1,-1,2.6,2.6,5),box(1.5,3.5,.7,1.6,1.2,1.6)],'outline':None}
parts['sensor_retainer']={'base':[box(0,0,0,45.5,3,1.5)],'base_cuts':[],'add':[],
 'cuts':[box(.3,.3,-1,2.4,2.4,4),box(42.8,.3,-1,2.4,2.4,4)],'outline':None}

def occupied_boxes(spec):
 # Split at base-cut boundaries; recover exact disjoint solid boxes before later union.
 b=spec['base'];cuts=spec['base_cuts']
 if not cuts:return b+spec['add']
 axes=[sorted({v for q in b+cuts for v in (q[k],q[k+3])}) for k in range(3)]
 result=[]
 for i in range(len(axes[0])-1):
  for j in range(len(axes[1])-1):
   for k in range(len(axes[2])-1):
    lo=[axes[d][n] for d,n in enumerate((i,j,k))];hi=[axes[d][n+1] for d,n in enumerate((i,j,k))];p=[(lo[d]+hi[d])/2 for d in range(3)]
    def ins(q):return all(q[d]<p[d]<q[d+3] for d in range(3))
    if any(ins(q) for q in b) and not any(ins(q) for q in cuts):result.append(tuple(lo+hi))
 return result+spec['add']

def scad_boxes(bs):
 return '\n'.join('translate(%s) cube(%s);'%(list(b[:3]),[round(b[i+3]-b[i],6) for i in range(3)]) for b in bs)
scad=['// TinyScreen+ 0.5 mm assumed-reach enclosure PROTOTYPE. Units mm.',
 '// Source matches exported STL geometry. Read README before printing.',
 '// Exact actuator plane, sensor depth, plugs and USB access are not measured.',
 'part="assembly"; // front_shell, rear_lid, board_cradle, side_button_0p5, stop_collar, sensor_retainer, assembly',
 'button_release=0.5; // assembly preview only: 0=fully pressed, 0.5=assumed resting state',
 'module solid_outline(){linear_extrude(height=100) polygon('+json.dumps(outline)+');}']
report=[]
for name,spec in parts.items():
 print('Building '+name,flush=True)
 tris,vol=make_mesh(spec['base'],spec['cuts'],spec['outline'],spec['base_cuts'],spec['add'])
 report.append(write_stl(name,tris,vol))
 body='difference(){union(){difference(){union(){'+scad_boxes(spec['base'])+'}union(){'+scad_boxes(spec['base_cuts'])+'}}'+scad_boxes(spec['add'])+'}union(){'+scad_boxes(spec['cuts'])+'}}'
 if spec['outline']:body='intersection(){'+body+'solid_outline();}'
 scad.append('module '+name+'(){'+body+'}')
 scad.append('if(part=="'+name+'") '+name+'();')
scad.append('''
module left_button(y){translate([-2-button_release,y-2.5,2]) multmatrix([[0,0,1,0],[1,0,0,0],[0,1,0,0],[0,0,0,1]]) side_button_0p5();}
module right_button(y){translate([64,0,0]) mirror([1,0,0]) left_button(y);}
module left_collar(y){translate([6.7-button_release,y-2.3,2.2]) multmatrix([[0,0,1,0],[1,0,0,0],[0,1,0,0],[0,0,0,1]]) stop_collar();}
module right_collar(y){translate([64,0,0]) mirror([1,0,0]) left_collar(y);}
if(part=="assembly"){
 color("lightgray") front_shell();
 translate([76,0,0]) color("silver") rear_lid();
 translate([16.8,13.3,26.4]) mirror([0,0,1]) color("orange") board_cradle();
 for(y=[28.05,34.95]){ color("orange") left_button(y);color("orange") right_button(y);color("gray") left_collar(y);color("gray") right_collar(y); }
 translate([12,52.5,8.4]) color("orange") sensor_retainer();
 %translate([19,15.5,2.4]) cube([26,25,21]);
 %translate([16,44,6]) cube([18,10,1.2]);
 %translate([36.5,43.5,6]) cube([17,11,1.2]);
 %translate([22.5,56.3,2]) cube([19,23,5]);
}
''')
(OUT/'TinyScreen_console.scad').write_text('\n'.join(scad))
(OUT/'dimensions.json').write_text(json.dumps(P,indent=2))
(OUT/'mesh_validation.json').write_text(json.dumps(report,indent=2))
(OUT/'geometry_definition.json').write_text(json.dumps(parts,indent=2))
print(json.dumps(report,indent=2))
