# TinyScreen+ thermal console CAD prototype — 0.5 mm assumed reach

This package builds the approved 64 x 82 x 40 mm console concept into editable CAD and six printable part types. All units are millimetres. It is a fabrication prototype, not a verified drop-in fit. The 0.5 mm button test result was assumed by request, not observed.

## Open and edit

Open `TinyScreen_console.scad` in OpenSCAD. The default `part="assembly"` shows the shell, buttons, sensor retainer and cradle, with the rear lid placed beside the shell. Transparent hardware blocks are reference envelopes, not printed parts. Set `part` to a component name to isolate it, then render with F6 and export. Individual `edit_*.scad` files open each component directly.

The source contains editable CSG primitives matching the STL exports. `dimensions.json` records measurements/defaults; changing that JSON alone does not rebuild the model. `rebuild_console.py` regenerates the geometry and source using Python's standard library. Edit dimensions and the corresponding geometry definitions in that script to make design changes. `check_assembly.py` checks the modeled printed-part clearances. No STEP or native FreeCAD file is included. OpenSCAD itself was not available here; the supplied STLs were built and checked independently from the same CSG definitions.

## Print list

| STL | Quantity | Purpose |
|---|---:|---|
| front_shell.stl | 1 | Rounded shell, front apertures, button guides, sensor/battery trays, screw bosses |
| rear_lid.stl | 1 | Four-screw lid with locating lips and cradle spacer posts |
| board_cradle.stl | 1 | Removable rear support ring with PCB locating fences |
| side_button_0p5.stl | 4 | Independent side buttons with long 2.4-square shafts |
| stop_collar.stl | 4 | Removable shaft collars; optional M2 locking screws |
| sensor_retainer.stl | 1 | Rear bar retaining the sensor PCBs using compliant edge pads |

Six unique STL files, twelve printed pieces total. M2 screws and soft pads/strap are not printed or supplied.

## Dimensions and mechanism

- Body 64 W x 82 H x 40 D, 2 mm nominal walls, R6 corners in front/back outline. Corners use eight facets per quarter-circle. Depth edges are square, without the cosmetic soft fillets of the concept illustration.
- Body width excludes button heads: approximately 69 mm across heads in the assumed resting position.
- Screen opening 25 x 16.5, upper-left at x=19.5, y=24. Concealed 8-high upper hardware strip is behind the bezel, included in the 25-high board outline, not added twice. Blind internal relief leaves a 0.8 mm front skin in that area.
- Board measured 26 x 25 x 21; reserved depth 22. Proposed front display datum z=2.4. Board location x=19, y=15.5. Do not push the display glass against the bezel.
- Buttons at y=28.05 and 34.95 on both sides, giving 6.9 pitch. These absolute positions were inferred from the reported lower-edge dimensions.
- Button axis z=4.5 is STILL A PLACEHOLDER. Reported 0.3 mm screen separation does not establish actuator center depth or operating travel.
- Each side has two spaced 3-square guide bores. Shafts are 2.4 square, giving nominal 0.3 sliding clearance per side.
- Left inner guide face x=18.5, proposed resting actuator-tip plane x=18.5. Fully pressed nose reaches x=19.0, hence 0.5 reach past that guide. Right side is mirrored. The case head is the inward travel stop. This assumes actuator protrusion and alignment that still need a physical check.
- In assembly preview, `button_release=0.5` shows the assumed resting position. Set it to zero to see the fully pressed stop position. This variable affects preview placement, not STL shaft length.
- Collars are positioned in the gap between outer and inner guides. At full press, left collar spans x=6.7..9.7. At assumed rest it spans x=6.2..9.2. It can act as an outward retention stop; its position must be calibrated before locking. Use only light screw pressure to avoid distorting the shaft.
- The PCB rear is expected near z=23.4. Cradle support face is z=24.4. Fill the nominal 1 mm gap with suitable soft pads on verified bare PCB edge areas. Front datum and pad thickness require fit adjustment. Do not load PCB components or OLED glass. Cradle fences have 0.2 nominal lateral clearance per side.

## Sensors, battery and cables

- Camera PCB pocket 18.4 x 10.4, center (25,49). Buzzer PCB pocket 17.4 x 11.4, center (45,49). These add 0.4 TOTAL in-plane clearance, 0.2 each side.
- Camera aperture 11 x 7, center (23.5,49), accounting provisionally for the housing offset on the PCB. This is a proposed opening, not a confirmed optical result. Keep it uncovered. Camera-face recess, optical-center offset and field of view must be checked on hardware.
- PCB edge seats are z=6; assumed PCB thickness is 1.2. These depths are UNMEASURED defaults. Edge ledges and a removable sensor retainer allow soft pad adjustment; avoid all components when choosing pad positions. Leave the camera face as close to the front opening as possible, without protrusion or stress.
- Sensor-retainer underside z=8.4 leaves nominal pad space above assumed PCB backs at z=7.2. Its two screws are outside the PCB edges. Use soft pads only on suitable edge areas and do not over-tighten.
- Battery pocket 25 x 24 x 7; actual battery 19 x 23 x 5. Pocket lower-left placement x=19.5, y=55.8. It is open toward the board for lead exit. Slots in side walls accept a soft retaining strap; do not compress or puncture the pouch.
- Both ~50 mm Wireling cables exit toward the stack through open tray ends. There is space around the guides and cradle for routing, but no exact plug solids or cable bend curves have been validated.
- The confirmed 0.4 extra wire/plug allowance is ADDITIONAL to the physical plug/bend envelope. It is not a 0.4 mm cable slot and does not prove those cables fit.

## Hardware and assembly

Suggested prototype hardware: four M2 x 6 screws for plastic into the rear bosses, two M2 x 5 screws for the sensor retainer, and up to four short M2 x 3 locking screws for collars. The nominal plastic pilots are 1.6 square; manually prepare/tap for the screw type as needed, using gentle force. Lid clearance holes are 2.4 square, with 4.4-square, 0.8-deep head pockets. Some screw heads will remain proud. Do not substitute longer screws without checking depth.

1. First check the short button-fit test from the earlier kit. This complete-case package assumes its 0.5 version worked; it does not replace that test.
2. Print shell, one long button and one collar first if possible. Verify free sliding without electronics, checking for first-layer burrs. Adjust printer fit rather than forcing it.
3. From outside, insert a shaft through the outer guide. Before pushing it through the inner guide, slip its loose collar over the shaft in the accessible guide gap. Then engage the inner guide. Repeat for four buttons.
4. With power disconnected, place the board stack and check actuator alignment. Do not close the lid if any switch is preloaded. Adjust shaft/guide geometry if necessary.
5. Fit the rear cradle and suitable soft edge pads. Trial-fit the lid without screws, verifying that it closes freely without bending the boards or loading the glass. Lid spacer posts hold the cradle; they are not intended to force the electronics into place.
6. Position sensors on their edge ledges, verify housing/window alignment, route cables without tight bends, and fit the padded sensor retainer. Leave the camera aperture uncovered.
7. Install battery with a soft loose retainer and verify lead reach. Keep leads clear of guides, screw bosses and lid edges. Gently test individual button presses/releases before securing the lid.

## Printing

Starting point: PLA or PETG, 0.4 nozzle, 0.16-0.20 layers, three or four walls. Shell prints front face down; guide bores are small horizontal bridges and may need locally controlled supports depending on printer. Keep support scars out of the sliding bores. Lid prints outside face down with posts upward. Cradle prints ring face down; buttons print heads down; collars print through-bores vertical; retainer prints flat. Use slicer preview to inspect bridging. Printed sliding fit and small pilot holes are printer-dependent.

## Access not yet finalized

Permanent USB and power-switch cutouts have NOT been guessed or cut. Their locations must be measured and added to the source before a final complete-case print. The rear lid is removable for service, but assembled USB access is not guaranteed. This limitation was retained from the unverified access positions in the approved preview.

## Validation and remaining limits

Each exported binary STL was checked for nondegenerate faces, closed edges, consistent orientation, one connected component and expected solid volume. Printed-part CSG clearance checks found no positive-volume overlap in the modeled fully pressed and assumed resting states. `mesh_validation.json` and `assembly_clearance_checks_*.json` contain results. The preview was rendered from actual exported meshes; its blue screen is only a reference panel.

These checks do not establish hardware fit, switch safety, return force, optical clearance, printer tolerances, cable reach or electrical function. No physical print has been tested. Before committing to a final shell, confirm button axis depth/travel, actuator-tip plane, sensor seat heights, camera optical offset, plug envelopes and USB/power access. The design is a prototype built from the agreed dimensions, with these defaults clearly identified.
