// TinyScreen+ 0.5 mm assumed-reach enclosure PROTOTYPE. Units mm.
// Source matches exported STL geometry. Read README before printing.
// Exact actuator plane, sensor depth, plugs and USB access are not measured.
part="assembly"; // front_shell, rear_lid, board_cradle, side_button_0p5, stop_collar, sensor_retainer, assembly
button_release=0.5; // assembly preview only: 0=fully pressed, 0.5=assumed resting state
module solid_outline(){linear_extrude(height=100) polygon([[64.0, 76.0], [63.884712, 77.170542], [63.543277, 78.296101], [62.988818, 79.333421], [62.242641, 80.242641], [61.333421, 80.988818], [60.296101, 81.543277], [59.170542, 81.884712], [58.0, 82.0], [6.0, 82.0], [4.829458, 81.884712], [3.703899, 81.543277], [2.666579, 80.988818], [1.757359, 80.242641], [1.011182, 79.333421], [0.456723, 78.296101], [0.115288, 77.170542], [0.0, 76.0], [0.0, 6.0], [0.115288, 4.829458], [0.456723, 3.703899], [1.011182, 2.666579], [1.757359, 1.757359], [2.666579, 1.011182], [3.703899, 0.456723], [4.829458, 0.115288], [6.0, 0.0], [58.0, 0.0], [59.170542, 0.115288], [60.296101, 0.456723], [61.333421, 1.011182], [62.242641, 1.757359], [62.988818, 2.666579], [63.543277, 3.703899], [63.884712, 4.829458], [64.0, 6.0]]);}
module front_shell(){intersection(){difference(){union(){difference(){union(){translate([0, 0, 0]) cube([64, 82, 38]);}union(){translate([6, 2, 2]) cube([52, 78, 38]);
translate([2, 6, 2]) cube([60, 70, 38]);
translate([3.5, 3.5, 2]) cube([57.0, 75.0, 38]);
translate([19.5, 24, -1]) cube([25.0, 16.5, 4]);
translate([18.8, 15.3, 0.8]) cube([26.4, 25.4, 1.3]);
translate([18, 45.5, -1]) cube([11, 7.0, 4]);
translate([41, 46.5, -1]) cube([8, 1.0, 4]);
translate([41, 48.5, -1]) cube([8, 1.0, 4]);
translate([41, 50.5, -1]) cube([8, 1.0, 4]);}}translate([1.5, 25.55, 1.9]) cube([4.5, 5.0, 5.1]);
translate([14.5, 25.55, 1.9]) cube([4.0, 5.0, 5.1]);
translate([45.5, 25.55, 1.9]) cube([4.0, 5.0, 5.1]);
translate([58, 25.55, 1.9]) cube([4.5, 5.0, 5.1]);
translate([1.5, 32.45, 1.9]) cube([4.5, 5.0, 5.1]);
translate([14.5, 32.45, 1.9]) cube([4.0, 5.0, 5.1]);
translate([45.5, 32.45, 1.9]) cube([4.0, 5.0, 5.1]);
translate([58, 32.45, 1.9]) cube([4.5, 5.0, 5.1]);
translate([3.5, 3.5, 1.9]) cube([7.0, 7.0, 36.1]);
translate([53.5, 3.5, 1.9]) cube([7.0, 7.0, 36.1]);
translate([3.5, 71.5, 1.9]) cube([7.0, 7.0, 36.1]);
translate([53.5, 71.5, 1.9]) cube([7.0, 7.0, 36.1]);
translate([14.6, 43.8, 1.9]) cube([1.2, 10.4, 6.5]);
translate([34.2, 43.8, 1.9]) cube([1.2, 10.4, 6.5]);
translate([15.8, 43.8, 1.9]) cube([0.8, 10.4, 4.1]);
translate([33.4, 43.8, 1.9]) cube([0.8, 10.4, 4.1]);
translate([14.6, 54.2, 1.9]) cube([20.8, 1.2, 6.5]);
translate([35.1, 43.3, 1.9]) cube([1.2, 11.4, 6.5]);
translate([53.7, 43.3, 1.9]) cube([1.2, 11.4, 6.5]);
translate([36.3, 43.3, 1.9]) cube([0.8, 11.4, 4.1]);
translate([52.9, 43.3, 1.9]) cube([0.8, 11.4, 4.1]);
translate([35.1, 54.7, 1.9]) cube([19.8, 1.2, 6.5]);
translate([12.0, 52.5, 1.9]) cube([3.0, 3.0, 6.5]);
translate([54.5, 52.5, 1.9]) cube([3.0, 3.0, 6.5]);
translate([18.3, 55.8, 1.9]) cube([1.2, 24.0, 7.1]);
translate([44.5, 55.8, 1.9]) cube([1.2, 24.0, 7.1]);
translate([18.3, 79.8, 1.9]) cube([27.4, 1.2, 7.1]);}union(){translate([-1, 26.55, 3]) cube([19.6, 3.0, 3]);
translate([45.4, 26.55, 3]) cube([19.6, 3.0, 3]);
translate([-1, 33.45, 3]) cube([19.6, 3.0, 3]);
translate([45.4, 33.45, 3]) cube([19.6, 3.0, 3]);
translate([6.2, 6.2, 29.5]) cube([1.6, 1.6, 9.5]);
translate([56.2, 6.2, 29.5]) cube([1.6, 1.6, 9.5]);
translate([6.2, 74.2, 29.5]) cube([1.6, 1.6, 9.5]);
translate([56.2, 74.2, 29.5]) cube([1.6, 1.6, 9.5]);
translate([12.7, 53.2, 4]) cube([1.6, 1.6, 5]);
translate([55.2, 53.2, 4]) cube([1.6, 1.6, 5]);
translate([18, 65, 4]) cube([1.8, 4, 2]);
translate([44.2, 65, 4]) cube([1.8, 4, 2]);}}solid_outline();}}
if(part=="front_shell") front_shell();
module rear_lid(){intersection(){difference(){union(){difference(){union(){translate([0, 0, 0]) cube([64, 82, 2]);
translate([12, 2.2, 2]) cube([40, 1.0, 1]);
translate([12, 78.8, 2]) cube([40, 1.0, 1]);
translate([2.2, 12, 2]) cube([1.0, 58, 1]);
translate([60.8, 12, 2]) cube([1.0, 58, 1]);
translate([16.8, 13.3, 1.9]) cube([3.0, 3.0, 11.7]);
translate([44.2, 13.3, 1.9]) cube([3.0, 3.0, 11.7]);
translate([16.8, 39.7, 1.9]) cube([3.0, 3.0, 11.7]);
translate([44.2, 39.7, 1.9]) cube([3.0, 3.0, 11.7]);}union(){}}}union(){translate([5.8, 5.8, -1]) cube([2.4, 2.4, 5]);
translate([4.8, 4.8, -0.1]) cube([4.4, 4.4, 0.9]);
translate([55.8, 5.8, -1]) cube([2.4, 2.4, 5]);
translate([54.8, 4.8, -0.1]) cube([4.4, 4.4, 0.9]);
translate([5.8, 73.8, -1]) cube([2.4, 2.4, 5]);
translate([4.8, 72.8, -0.1]) cube([4.4, 4.4, 0.9]);
translate([55.8, 73.8, -1]) cube([2.4, 2.4, 5]);
translate([54.8, 72.8, -0.1]) cube([4.4, 4.4, 0.9]);}}solid_outline();}}
if(part=="rear_lid") rear_lid();
module board_cradle(){difference(){union(){difference(){union(){translate([0, 0, 0]) cube([30.4, 29.4, 2]);}union(){translate([2.7, 2.7, -1]) cube([25.0, 24.0, 4]);}}translate([0.8, 0.8, 1.9]) cube([1.2, 27.8, 3.1]);
translate([28.4, 0.8, 1.9]) cube([1.2, 27.8, 3.1]);
translate([0.8, 0.8, 1.9]) cube([28.8, 1.2, 3.1]);
translate([0.8, 27.4, 1.9]) cube([28.8, 1.2, 3.1]);}union(){}}}
if(part=="board_cradle") board_cradle();
module side_button_0p5(){difference(){union(){difference(){union(){translate([0, 0, 0]) cube([5, 5, 2]);
translate([1.3, 1.3, 1.9]) cube([2.4, 2.4, 19.1]);}union(){}}}union(){}}}
if(part=="side_button_0p5") side_button_0p5();
module stop_collar(){difference(){union(){difference(){union(){translate([0, 0, 0]) cube([4.6, 4.6, 3]);}union(){}}}union(){translate([1, 1, -1]) cube([2.6, 2.6, 5]);
translate([1.5, 3.5, 0.7]) cube([1.6, 1.2, 1.6]);}}}
if(part=="stop_collar") stop_collar();
module sensor_retainer(){difference(){union(){difference(){union(){translate([0, 0, 0]) cube([45.5, 3, 1.5]);}union(){}}}union(){translate([0.3, 0.3, -1]) cube([2.4, 2.4, 4]);
translate([42.8, 0.3, -1]) cube([2.4, 2.4, 4]);}}}
if(part=="sensor_retainer") sensor_retainer();

module left_button(y){translate([-2-button_release,y-2.5,2]) multmatrix([[0,0,1,0],[1,0,0,0],[0,1,0,0],[0,0,0,1]]) side_button_0p5();}
module right_button(y){translate([64,0,0]) mirror([1,0,0]) left_button(y);}
module left_collar(y){translate([6.7-button_release,y-2.3,2.2]) multmatrix([[0,0,1,0],[1,0,0,0],[0,1,0,0],[0,0,0,1]]) stop_collar();}
module right_collar(y){translate([64,0,0]) mirror([1,0,0]) left_collar(y);}
if(part=="assembly"){
 color("lightgray") front_shell();
 translate([76,0,0]) color("silver") rear_lid();
 translate([16.8,13.3,26.4]) mirror([0,0,1]) color("orange") board_cradle();
 for(y=[28.05,34.95]){ color("orange") left_button(y);color("orange") right_button(y);color("gray") left_collar(y);color("gray") right_collar(y); }
 translate([12,52.5,8.4]) color("orange") sensor_retainer();
 %translate([19,15.5,2.4]) cube([26,25,21]);
 %translate([16,44,6]) cube([18,10,1.2]);
 %translate([36.5,43.5,6]) cube([17,11,1.2]);
 %translate([22.5,56.3,2]) cube([19,23,5]);
}
