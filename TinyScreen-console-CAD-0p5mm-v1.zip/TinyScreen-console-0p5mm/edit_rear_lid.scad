// Units mm. Read README. Isolated printable component.
use <TinyScreen_console.scad>;
rear_lid();
